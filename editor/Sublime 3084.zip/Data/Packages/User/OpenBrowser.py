import sublime, sublime_plugin
import webbrowser

class open_browserCommand(sublime_plugin.TextCommand):
   def run(self,edit):
      url = self.view.file_name()
      webbrowser.open_new(url)
