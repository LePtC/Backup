## Stop!

Do **NOT** submit an issue here until you have:

- Read the [installation](http://sublimelinter.readthedocs.org/en/latest/installation.html) and [troubleshooting](http://sublimelinter.readthedocs.org/en/latest/troubleshooting.html) documentation.

- Posted a message on the [SublimeLinter support forum](https://groups.google.com/forum/#!forum/sublimelinter).

- Verified on the support forum that you have actually found a bug in SublimeLinter.

Thank you!
