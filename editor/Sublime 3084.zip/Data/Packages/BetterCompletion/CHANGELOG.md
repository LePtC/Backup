<a name="2015-03-02T10:36:08.365Z"></a>
# 1.4.2 (2015-03-02)


## Bug Fixes

- **api:** fast fix sql api typo
  ([bd02b81c](https://github.com/Pleasurazy/Sublime-Better-Completion/commit/bd02b81c2cdd830b8ee05ae5ede219f68dbabf5c))


<a name="2015-02-26T16:16:35.947Z"></a>
# 1.4.1 (2015-02-27)


## Bug Fixes

- **api:** missing javascript api
  ([786d785b](https://github.com/Pleasurazy/Sublime-Better-Completion/commit/786d785b2e79465b145df84e2fabca0ed526cefb))


<a name="2015-02-26T16:11:59.489Z"></a>
# 1.4.0 (2015-02-27)


## Bug Fixes

- **api:** missing bootstrap class
  ([f01ef9f8](https://github.com/Pleasurazy/Sublime-Better-Completion/commit/f01ef9f89080d81df9e2ad2cbbda7f1eeb71f1d2))


## Features

- **api:**
  - add css3 properties api
  ([efb585f2](https://github.com/Pleasurazy/Sublime-Better-Completion/commit/efb585f281d46fc3eb97ef3e5adae5cb6779ce91))
  - add lodash api
  ([6e3a5023](https://github.com/Pleasurazy/Sublime-Better-Completion/commit/6e3a50234ad41014bb9cd091e97dbe9f39d0f5b6))
  - add bootstrap less variables
  ([cfc25d88](https://github.com/Pleasurazy/Sublime-Better-Completion/commit/cfc25d88a105854e6d4f356f56b6581ffb893fbd))

